# ICS3U Final Project

A short horror game where you try to help 2 NPCs escape from the game they're trapped in, to the consternation of the game's developer.

## Packages that need to be installed:
- Pygame

## Known bugs:
- Sometimes when bumping against a wall the player sprite will fly offscreen. The way to fix this is to restart the program.
- Text might not display when trying to enter a room and the room itself might not load. Trying again usually fixes this problem. Entering another room and then exiting might also help.

## Cheat codes:

- ### To complete the game, you need to:
  - Say yes when it asks you if you want to search the bathroom cabinet, giving you pills.
  - Go to the medical wing so the nurse gives you a third (1) of the key mould for the pills.
  - Say yes when it asks you if you want to search the office drawer to get a matchbook and candle.
  - Say yes when the gardener asks you if you want to have some poppies.
  - Go to the kitchen and exchange the poppies for a spoon and some poppy tea.
  - Go back to the greenhouse, say yes when it prompts you to drug the gardener, and get another third (2) of the key mould.
  - Go to the rec room, say yes when the Random NPC prompts you to play a game of rock paper scissors, spam whatever key you feel like (it will automatically set you to rock if you don't choose r, p, or s), and wait until you get three wins. This gives you the last third (3) of the key mould.
  - Go to the dining room and exchange your spoon and candle for a butcher knife.
  - Go to Jan's room and get a corrupt file (1).
  - Go to Aspen's and get the stone key and a second corrupt file (2).
  - Go to [REDACTED] and finish the game.

## Support:

- Email me at awang28@ocdsb.ca

## Sources:

- https://realpython.com/pygame-a-primer/
  - I used this to learn the basics of pygame.
- https://www.techwithtim.net/tutorials/game-development-with-python/side-scroller-pygame/background/
  - I didn't use this much, but I looked through it when trying to figure out how to move a background. The actual method used in my game is one I came up with on my own; I just move the coordinates of everything, though the concept is similar.
- https://www.youtube.com/watch?v=abH2MSBdnWc
  - I used this to figure out how to generate a tile map. In the video I believe it uses a list; my game uses a .txt file, but the concept is the same.
- http://programarcadegames.com/index.php?&chapter=example_code_platformer
  - I based a lot of my collision from this source.
- https://pythonprogramming.net/displaying-text-pygame-screen/
  - I learned how text is rendered to the screen from this source.
- https://pygame.readthedocs.io/en/latest/5_app/app.html
  - I based my text box class off of what is in here.
- https://www.geeksforgeeks.org/python-display-text-to-pygame-window/
  - I learned how to display text here as well.
- https://www.geeksforgeeks.org/python-program-to-read-character-by-character-from-a-file/
  - I learned how to read through a .txt file to generate my map.