"""
Jayden Wang
ICS3U
A fun game where you try to free the NPCs trapped inside.
"""

import pygame as py

from pygame.locals import (
  K_UP,
  K_DOWN,
  K_LEFT,
  K_RIGHT,
  K_ESCAPE,
  K_SPACE,
  K_RETURN,
  K_BACKSPACE,
  KEYDOWN,
  QUIT
)

from pygame import mixer

import classes as cl

import functions as fn

#Width and height of screen.
SCREEN_WIDTH=800
SCREEN_HEIGHT=900

py.init()
mixer.init()

#Load the screen.
screen=py.display.set_mode([SCREEN_WIDTH, SCREEN_HEIGHT])

#Create the player and map instances. Draw the map.
player=cl.Player(100, 100)
map=cl.Map(0, 0)
map.draw()

#Text instances needed in the map display.
text_your_room=cl.Text_box("Press enter to enter your room.", 30, 880, (255, 255, 255))
text_bathroom=cl.Text_box("Press enter to enter the bathroom.", 30, 880, (255, 255, 255))
text_aspen_room=cl.Text_box("Press enter to enter Aspen's room.", 30, 880, (255, 255, 255))
text_jan_room=cl.Text_box("Press enter to enter Jan's room.", 30, 880, (255, 255, 255))
text_main_office=cl.Text_box("Press enter to enter the office.", 30, 880, (255, 255, 255))
text_medical_wing=cl.Text_box("Press enter to enter the medical wing.", 30, 880, (255, 255, 255))
text_kitchen=cl.Text_box("Press enter to enter the kitchen.", 30, 880, (255, 255, 255))
text_dining_room=cl.Text_box("Press enter to enter the dining room.", 30, 880, (255, 255, 255))
text_greenhouse=cl.Text_box("Press enter to enter the greenhouse.", 30, 880, (255, 255, 255))
text_rec_room=cl.Text_box("Press enter to enter the rec room.", 30, 880, (255, 255, 255))
text_redacted=cl.Text_box("Press enter to enter [REDACTED].", 30, 880, (255, 255, 255))

cl.player.render()

clock=py.time.Clock()

running=True

location="map"

#Always call start first.
fn.start()

#Load music and set volume.
mixer.music.load("horrormusic.mp3")
mixer.music.set_volume(0.6)

#Play the music infinitely while the program is running.
mixer.music.play(-1)

#Game main loop.
while running:
  for event in py.event.get():
    #Allows you to leave the game by breaking the loop.
    if event.type == KEYDOWN:
      if event.key == K_BACKSPACE:
        running = False
      #Calls the shift method and notes the direction the player has moved as well.
      if event.key == K_LEFT:
        map.shift(2, 0)
        map.change_x_left+=2
        map.change_x_right=0
        map.change_y_up=0
        map.change_y_down=0

      if event.key == K_RIGHT:
        map.shift(-2, 0)
        map.change_x_right+=2
        map.change_x_left=0
        map.change_y_up=0
        map.change_y_down=0
        
      if event.key == K_UP:
        map.shift(0, -2)
        map.change_y_up+=2
        map.change_y_down=0
        map.change_x_left=0
        map.change_x_right=0
        
      if event.key == K_DOWN:
        map.shift(0, 2)
        map.change_y_down+=2
        map.change_y_up=0
        map.change_x_left=0
        map.change_x_right=0

      #Allows player to 'enter' rooms by changing location.
      if event.key==K_RETURN:
        #Measures player's rectangle coordinate distance from sprites in different sprite groups.
        for entity in cl.your_room_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
            #Changes location accordingly.
            location="your room"
        for entity in cl.bathroom_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
            location="bathroom"
        for entity in cl.aspen_room_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
            location="aspen's room"
        for entity in cl.jan_room_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
            location="jan's room"
        for entity in cl.office_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
            location="main office"
        for entity in cl.med_wing_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
            location="medical wing"
        for entity in cl.kitchen_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
            location="kitchen"
        for entity in cl.dining_room_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
            location="dining room"
        for entity in cl.greenhouse_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=60:
            location="greenhouse"
        for entity in cl.rec_room_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=60:
            location="rec room"
        for entity in cl.redacted_sprites:
          if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
            location="redacted"

        #Calls the function corresponding to location value.
        if location=="greenhouse":
          fn.poppies, fn.key_mould=fn.greenhouse(fn.matchbook, fn.poppy_tea, fn.key_mould, fn.poppies)
          #Always reset location to map.
          location="map"
        elif location=="your room":
          fn.your_room()
          location="map"
        elif location=="bathroom":
          fn.pill_bottle=fn.bathroom(fn.pill_bottle)
          location="map"
        elif location=="aspen's room":
          fn.stone_key, fn.corrupt_files=fn.aspen_room(fn.key_mould, fn.corrupt_files, fn.call_track, fn.stone_key)
          #Increase call_track by one every time you visit Jan's or Aspen's room.
          fn.call_track[0]+=1
          location="map"
        elif location=="jan's room":
          fn.corrupt_files=fn.jan_room(fn.butcher_knife, fn.corrupt_files, fn.call_track)
          fn.call_track[1]+=1
          location="map"
        elif location=="main office":
          fn.matchbook, fn.wax_candle=fn.main_office(fn.matchbook, fn.wax_candle)
          location="map"
        elif location=="medical wing":
          fn.key_mould=fn.medical_wing(fn.pill_bottle, fn.key_mould)
          location="map"
        elif location=="kitchen":
          fn.spoon, fn.poppy_tea=fn.kitchen(fn.poppies, fn.spoon, fn.poppy_tea)
          location="map"
        elif location=="dining room":
          fn.butcher_knife=fn.dining_room(fn.spoon, fn.wax_candle, fn.butcher_knife)
          location="map"
        elif location=="rec room":
          fn.key_mould=fn.rec_room(fn.key_mould)
          location="map"
        elif location=="redacted":
          fn.end=fn.REDACTED(fn.stone_key, fn.corrupt_files, fn.end)
          #Call game_over if end is True, then change the screen to black, update it, and break the loop, ending the game.
          if fn.end==True:
            fn.game_over()
            screen.fill((0, 0, 0))
            py.display.flip()
            running=False

    #Stops the map from moving all the time by resetting the shift values to zero.
    elif event.type == py.KEYUP:
      if event.key == K_LEFT:
        map.shift(0, 0)

      elif event.key == K_RIGHT:
        map.shift(0, 0)

      elif event.key == K_UP:
        map.shift(0, 0)

      elif event.key == K_DOWN:
        map.shift(0, 0)
        
    elif event.type == QUIT:
      running = False

  #Fill the screen with a nice shade of dystopia grey.
  screen.fill((219, 215, 210))
  
  player.update(map)
  #Updates the map.
  map.update()

  clock.tick()

  #Load every map sprite and the player as well.
  for entity in cl.collide_sprites:
    screen.blit(entity.picture, entity.rect)

  for entity in cl.player_sprites:
    screen.blit(entity.surf, entity.rect)

  #Draw the text box itself.
  rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 800, 800, 100))

  #Display text according to how close you are to a room's sprites, just so you know where you're going.
  for entity in cl.your_room_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_your_room.draw()
  for entity in cl.bathroom_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_bathroom.draw()
  for entity in cl.aspen_room_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_aspen_room.draw()
  for entity in cl.jan_room_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_jan_room.draw()
  for entity in cl.office_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_main_office.draw()
  for entity in cl.med_wing_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_medical_wing.draw()
  for entity in cl.kitchen_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_kitchen.draw()
  for entity in cl.dining_room_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_dining_room.draw()
  for entity in cl.greenhouse_sprites:
    if abs(player.rect.x-entity.rect.x)<=64 and abs(player.rect.y-entity.rect.y)<=64:
      text_greenhouse.draw()
  for entity in cl.rec_room_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_rec_room.draw()
  for entity in cl.redacted_sprites:
    if abs(player.rect.x-entity.rect.x)<=32 and abs(player.rect.y-entity.rect.y)<=32:
      text_redacted.draw()

  py.display.update()

#Quits running the program once the main loop is broken.
py.quit()

