import pygame as py

from pygame.locals import (
  K_UP,
  K_DOWN,
  K_LEFT,
  K_RIGHT,
  K_ESCAPE,
  KEYDOWN,
  QUIT
)

SCREEN_WIDTH=800
SCREEN_HEIGHT=900

class Player(py.sprite.Sprite):
  """
  A class that represents the player.

  ...

  Attributes:
  ----------
  x: int
    The x-coordinate of the player sprite.
  y: int
    The y-coordinate of the player sprite.

  Methods:
  ----------
  render():
    Converts the player image and keeps the background transparent instead of black.
  """
  def __init__(self, x, y):
    """
    Constructs all the necessary attributes for the player object.

    Parameters:
    ----------
    x: int
      The x-coordinate of the player sprite.
    y: int
      The y-coordinate of the player sprite.
    """
    super(Player, self).__init__()

    #Create the surface of the player sprite and resize it.
    self.surf=py.image.load("player.png")
    self.surf=py.transform.scale(self.surf, (32, 64))

    #Change the starting coordinates to x and y.
    self.rect=self.surf.get_rect()   
    self.rect.y=y
    self.rect.x=x

  def render(self):
    """
    Converts the player image and keeps the background transparent instead of black.

    Parameters:
    ----------
    None

    Returns:
    ----------
    None
    """

    self.surf=self.surf.convert_alpha()

class Wall(py.sprite.Sprite):
  """
  A class that creates wall sprites.

  ...

  Attributes:
  ----------
  picture: str
    The picture to load for each wall sprite.

  Methods:
  ----------
  None
    
  """
  def __init__(self, picture):
    """
    Constructs all attributes necessary for the wall object.

    Parameters:
    ----------
    picture: str
      The picture to load for each wall sprite.

    """

    #Create the surface of the wall sprite.
    super(Wall, self).__init__()
    self.picture=py.image.load(picture)

    #Get its coordinates to be used later.
    self.rect=self.picture.get_rect()

class Map():
  """
  A class that generates and updates a map using wall sprites.

  ...

  Attributes:
  ----------
  x: int
    The x-coordinate of a sprite in the map.
  y: int
    The y-coordinate of a sprite in the map

  Methods:
  ----------
  draw():
    Draws the map using wall objects.
  shift(x, y):
    Records how much the map needs to be moved.
  update():
    Moves the map and handles collision.
  
  """
  def __init__(self, x, y):
    """
    Constructs all attributes necessary for the map object.

    Parameters:
    ----------
    x: int
      The x-coordinate of a sprite in the map.
    y: int
      The y-coordinate of a sprite in the map.
    
    """
    #Set the map coordinates,
    self.x=x
    self.y=y

    #Variables tracking change.
    #Set to 0, as nothing has moved yet.
    self.change_x=0
    self.change_y=0

    #Variables tracking direction.
    #Set to 0, as nothing has moved yet.
    self.change_x_left=0
    self.change_y_down=0
    self.change_y_up=0
    self.change_x_right=0
    
  def draw(self):
    """
    Reads through a text file, creates the according wall objects, and moves them, generating a map.

    Adds different types of sprites to their associated sprite groups.

    Parameters:
    ----------
    None

    Returns:
    ----------
    None
    """
    #Open the text file and read through every line.
    with open("Game Map.txt", "r") as a_file:
      lines=a_file.readlines()

      #Iterate through every line
      for row in lines:

        #Reset x to 0 every row of the map.
        self.x=0

        #Iterate through every character in a row.
        for char in row:

          #Create a different wall object for every different letter and add it to its specific sprite group.
          #Position the object properly so there is no overlap.
          char=lines[self.y][self.x]
          
          if char=="W":
            i=Wall("Tile Sprites/walltile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            wall_sprites.add(i)
            
          elif char=="S":
            i=Wall("Tile Sprites/your_roomtile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            your_room_sprites.add(i)
            
          elif char=="B":
            i=Wall("Tile Sprites/bathroom_tile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            bathroom_sprites.add(i)
            
          elif char=="A":
            i=Wall("Tile Sprites/aspen_roomtile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            aspen_room_sprites.add(i)
            
          elif char=="J":
            i=Wall("Tile Sprites/jan_roomtile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            jan_room_sprites.add(i)
            
          elif char=="O":
            i=Wall("Tile Sprites/office_tile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            office_sprites.add(i)
            
          elif char=="M":
            i=Wall("Tile Sprites/medical_wingtile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            med_wing_sprites.add(i)
            
          elif char=="G":
            i=Wall("Tile Sprites/greenhouse_tile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            greenhouse_sprites.add(i)
            
          elif char=="K":
            i=Wall("Tile Sprites/kitchen_tile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            kitchen_sprites.add(i)
            
          elif char=="R":
            i=Wall("Tile Sprites/rec_roomtile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            rec_room_sprites.add(i)
            
          elif char=="D":
            i=Wall("Tile Sprites/dining_roomtile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            dining_room_sprites.add(i)
            
          elif char=="L":
            i=Wall("Tile Sprites/redacted_tile.png")
            i.rect.move_ip(self.x*32, self.y*32)
            redacted_sprites.add(i)

          #Add all objects created to the global sprite group.
          collide_sprites.add(i)

          #Increase x with every character read.
          self.x+=1

        #Increase y with every row read through.
        self.y+=1

      #Reset both once the sprite is placed.
      self.x=0
      self.y=0
      
  def shift(self, x, y):
    """
    Records how much the map needs to be moved by noting how much the x-coordinates and y-coordinates of every sprite have changed.

    Parameters:
    ----------
    x: int
      The x-coordinate of a sprite in the map.
    y: int
      The y-coordinate of a sprite in the map.

    Returns:
    ----------
    None
    """

    #Set change_x and change_y. 
    self.change_x=x
    self.change_y=y
    
  def update(self):
    """
    Moves the map itself.
      Goes through every sprite in the map and changes its coordinates according to how much the map has been shifted.

    Handles collision.
      Checks what direction the map was last moving.
      Creates a list of how many map sprites have collided into the player sprite.
      Changes the player's coordinates accordingly.

    Parameters:
    ----------
    None

    Returns:
    ----------
    None
    """

    #Create a list of map sprites that the player is colliding with.
    block_hit_list=py.sprite.spritecollide(player, collide_sprites, False)

    #Iterate through each sprite.
    for block in block_hit_list:

      #Set the player's coordinates according to the block's coordinates and the player's direction of movement.
      if self.change_x_right!=0:
        player.rect.right=block.rect.left
      elif self.change_x_left!=0:
        player.rect.left=block.rect.right
      self.change_x=0
      
    block_hit_list=py.sprite.spritecollide(player, collide_sprites, False)
    for block in block_hit_list:
      if self.change_y_down!=0:
        player.rect.bottom=block.rect.top
      elif self.change_y_up!=0:
        player.rect.top=block.rect.bottom
      self.change_y=0

    #Move every sprite in the map.
    for entity in collide_sprites:
      entity.rect.x+=self.change_x
      entity.rect.y-=self.change_y

#Initialize font for the Text_box class.
py.font.init()

class Text_box:
  """
  A class that generates text boxes.

  ...

  Attributes:
  ----------
  text: str
    The text to use in the text box.
  x: int
    The x-coordinate of the text.
  y: int
    The y-coordinate of the text.
  fontcolour: tuple
    The RGB values for the text's font colour.

  Methods:
  ----------
  set_font():
    Sets the text's font.
  render():
    Renders the text as an image and loads its coordinates.
  draw():
    Puts the text box on the screen.
  remove():
    Removes the text by covering it with a rectangle.
  
  """
  def __init__(self, text, x, y, fontcolour):
    """
    Constructs all attributes necessary for the text box object.
      Renders the text, sets its font, and sets its font colour.

    Parameters:
    ----------
    text: str
      The text to use in the text box.
    x: int
      The x-coordinate of the text.
    y: int
      The y-coordinate of the text.
    fontcolour: tuple
      The RGB values for the text's font colour.
    
    """
    self.text=text
    self.colour=(0, 0, 0)
    self.x=x
    self.y=y

    self.fontsize=20
    self.fontcolour=fontcolour

    #Automatically loads the text's font and renders it upon initializing.
    self.set_font()
    self.render()
    
  def set_font(self):
    """
    Sets the text's font and its size.

    Parameters:
    ----------
    None

    Returns:
    ----------
    None
    
    """
    self.font=py.font.Font("Minecraft.ttf", self.fontsize)

  def render(self):
    """
    Renders the text as an image and sets the image's rectangle coordinates (x, y, width, height)

    Parameters:
    ----------
    None

    Returns:
    ----------
    None
    
    """
    self.img=self.font.render(self.text, True, self.fontcolour)
    self.rect=(self.x, self.y, 800, 30)

  def draw(self):
    """
    Draws the text to the screen.

    Parameters:
    ----------
    None

    Returns:
    ----------
    None
    
    """
    screen.blit(self.img, self.rect)

  def remove(self):
    """
    Removes the text from the screen by covering it with a rectangle.

    Parameters:
    ----------
    None

    Returns:
    ----------
    None
    """
    py.draw.rect(screen, (0, 0, 0), py.Rect(self.x, self.y, 800, 60))

#Individual sprite groups for different rooms and the wall.
wall_sprites=py.sprite.Group()
your_room_sprites=py.sprite.Group()
aspen_room_sprites=py.sprite.Group()
bathroom_sprites=py.sprite.Group()
dining_room_sprites=py.sprite.Group()
greenhouse_sprites=py.sprite.Group()
jan_room_sprites=py.sprite.Group()
kitchen_sprites=py.sprite.Group()
med_wing_sprites=py.sprite.Group()
office_sprites=py.sprite.Group()
rec_room_sprites=py.sprite.Group()
redacted_sprites=py.sprite.Group()

#Sprite group containing every map sprite, for collision.
collide_sprites=py.sprite.Group()

#Creates the player instance and adds it to the layer sprite group.
player=Player(100, 100)
player_sprites=py.sprite.Group()
player_sprites.add(player)

#Sets the screen.
screen=py.display.set_mode([SCREEN_WIDTH, SCREEN_HEIGHT])
