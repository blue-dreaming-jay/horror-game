import random as rand
import pygame as py
from pygame.locals import (
  K_RETURN,
  KEYDOWN,
  KEYUP,
  K_y,
  K_n,
  QUIT
)

import classes as cl

#Global variables
pill_bottle=False
stone_key=False
key_mould=[]
butcher_knife=False
wax_candle=False
matchbook=False
spoon=False
poppies=False
poppy_tea=False
corrupt_files=[]

end=False

call_track=[0, 0]

SCREEN_WIDTH=800
SCREEN_HEIGHT=900

#Text instances reused in multiple functions.
key_text1=cl.Text_box("It appears to be one third of a key mould.", 50, 880, (255, 255, 255))
key_text2=cl.Text_box("This could be useful.", 50, 880, (255, 255, 255))

text_yes_no=cl.Text_box("Press y for yes or n for no.", 50, 880, (255, 255, 255))

text_leave=cl.Text_box("You chose to leave.", 50, 880, (255, 255, 255))

def your_room():
  """
  Just your room. Doesn't do much.

  Parameters:
  None

  Returns:
  None
  """

  #Text instances local to specific functions.
  text_s1=cl.Text_box("You find yourself in your room.", 50, 880, (255, 255, 255))
  text_s2=cl.Text_box("It is rather plain.", 50, 880, (255, 255, 255))
  text_s3=cl.Text_box("The only defining feature is the bars on the window.", 50, 880, (255, 255, 255))
  text_s4=cl.Text_box("DEVon: please just go to the map and leave. backspace to leave.", 50, 880, (255, 255, 255))
  stay=True

  #Function main loop.
  while stay:

    #Load the background image.
    background=py.image.load("Room Art/your_room.png")
    screen.blit(background, (0, 0))
    py.display.flip()

    #Load the text box itself.
    rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
    py.display.update()

    #List of text boxes to be iterated through.
    text_boxes = [text_s1, text_s2, text_s3, text_s4, text_leave]
    #Index of the list.
    text_box_idx = 0
    
    current_text=text_boxes[text_box_idx]
    #Draw text and flip display.
    current_text.draw()
    py.display.flip()

    #text_box_idx is not the last thing updated in the loop and the text is already displaying when the loop ends, which is why it doesn't read while text_box_idx>4.
    while text_box_idx!=4:
      #Wait for an event to happen.
      event=py.event.wait()
      #If the user presses enter, remove the text already on display, make current_text the next text box object in the list, and draw it.
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    #Break the loop once everything has finished.
    stay=False
  return

def bathroom(pill_bottle):
  """
  A bathroom that lets you get a bottle of pills.

  Parameters:
  pill_bottle (bool): A bottle of pills. Can be traded.

  Returns:
  The boolean value of pill_bottle, depending on whether you chose to search a cabinet or not.
  """
  text_b1=cl.Text_box("The bathroom smells vaguely of antiseptic.", 50, 880, (255, 255, 255))
  text_b2=cl.Text_box("The counter has a toothpaste stain on it.", 50, 880, (255, 255, 255))

  text_b3=cl.Text_box("There appears to be a cabinet behind the mirror.", 50, 880, (255, 255, 255))
  text_b4=cl.Text_box("Search it?", 50, 880, (255, 255, 255))

  text_b5=cl.Text_box("You find an unlabeled bottle of pills.", 50, 880, (255, 255, 255))

  text_b6=cl.Text_box("Remembering many horror movie jumpscares, you left the cabinet alone.", 50, 880, (255, 255, 255))

  text_b7=cl.Text_box("DEVon: really, you should just quit.", 50, 880, (255, 255, 255))

  stay=True
  text=True
  waiting=True

  while stay:
    background=py.image.load("Room Art/bathroom.png")
    screen.blit(background, (0, 0))
    py.display.flip()
    rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
    py.display.update()

    text_boxes=[text_b1, text_b2]
    text_box_idx=0
    current_text=text_boxes[text_box_idx]
    current_text.draw()
    py.display.flip()

    #Loop that displays text.
    while text:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1

        #Starts this loop once all the beginning text has been displayed.
        if text_box_idx==2:
          if pill_bottle==False:
            text_boxes=[text_b3, text_b4, text_yes_no]
            text_box_idx=0
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
            while text_box_idx!=2:
              event=py.event.wait()
              if event.type==KEYDOWN and event.key==K_RETURN:
                current_text.remove()
                text_box_idx+=1
                current_text=text_boxes[text_box_idx]
                current_text.draw()
                py.display.flip()
            #Ensures that the user can only give input of y or n when waiting for a yes/no response.
            while waiting:
              #Start by waiting for an event.
              event=py.event.wait()

              if event.type==KEYDOWN and event.key==121:
                current_text.remove()
                current_text=text_b5
                event=py.event.wait()
                event=py.event.wait()
                while event.type!=KEYDOWN or event.key!=K_RETURN:
                  current_text.draw()
                  py.display.flip()
                  event=py.event.wait()
                #If user chose yes, pills are received.
                pill_bottle=True
                #Break the loop.
                waiting=False
                
              elif event.type==KEYDOWN and event.key==110:
                current_text.remove()
                current_text=text_b6
                event=py.event.wait()
                event=py.event.wait()
                while event.type!=KEYDOWN or event.key!=K_RETURN:
                  current_text.draw()
                  py.display.flip()
                  event=py.event.wait()
                #If user chose no, the loop simply breaks.
                waiting=False
              
              else:
                #Current text has not been changed yet, so this will keep the same thing on screen.
                current_text.draw()
                py.display.flip()

            #Breaks out of the text loop once whatever the user chose is complete.
            text=False 

          #Breaks out of the text loop if the user has already gotten pills. 
          else:
            text=False
        
        else:     
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()

    #Waiting is reset for a different loop.
    waiting=True
    #This function has a conditional, where it displays different text depending on the value of its parameters. However, all of the text needs to end in the same way.
    text_boxes=[text_b7, text_leave]
    #The previous text needs to be removed first. Setting it to -1 allows me to remove the text at the beginning without skipping anything.
    text_box_idx=-1
    while text_box_idx!=1:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False
      else:
        current_text.draw()
        py.display.flip()

    stay=False
        
  return pill_bottle

def aspen_room(key_mould, corrupt_files, call_track, stone_key):
  """
  Aspen's room. Plot relevant.

  Lets you get a stone key and a corrupt file, both of which are necessary to beat the game.

  Parameters:
  key_mould (list): A list of integers, each representing a third of the key mould. All three allow you to get the stone key.

  corrupt_files (list): A list of integers, each representing a corrupt file. 

  call_track (list): A list of two integers, each keeping track of how many times either Aspen's room or Jan's room has been visited.

  stone_key (bool): A stone key. Can be obtained once all three pieces of the key mould are found.

  Returns:
  The value of stone_key.
  corrupt_files, either with a number appended or no change at all.
  """
  text_a1=cl.Text_box("Inside the room is a person with wavy brown hair.", 50, 880, (255, 255, 255))
  text_a2=cl.Text_box("She is staring out the window.", 50, 880, (255, 255, 255))
  text_a3=cl.Text_box("There is nothing outside the window.", 50, 880, (255, 255, 255))
  text_a4=cl.Text_box("Aspen: Oh. I don't know what I expected.", 50, 880, (255, 255, 255))
  text_a5=cl.Text_box("Aspen: Are you happy, DEVon?", 50, 880, (255, 255, 255))
  text_a6=cl.Text_box("Aspen: Playing with our hopes like this?", 50, 880, (255, 255, 255))
  text_a7=cl.Text_box("DEVon: i don't exactly like that they're here.", 50, 880, (255, 255, 255))
  text_a8=cl.Text_box("DEVon: player, i suggest you leaaq20948023543985", 50, 880, (255, 255, 255))
  text_a9=cl.Text_box("iysdkgfhsadksjdfq384o5ohijdfksierhytguf9 o", 50, 880, (255, 255, 255))
  text_a10=cl.Text_box("Aspen: Yeah, shut your f***ing mouth.", 50, 880, (255, 255, 255))
  text_a11=cl.Text_box("Aspen: Listen, you really do need to help us.", 50, 880, (255, 255, 255))
  text_a12=cl.Text_box("Aspen: We're stuck inside this stupid world with no exit.", 50, 880, (255, 255, 255))
  text_a13=cl.Text_box("Aspen: There has to be some way to leave.", 50, 880, (255, 255, 255))
  text_a14=cl.Text_box("Aspen: We can't get out of these rooms, but..", 50, 880, (255, 255, 255))
  text_a15=cl.Text_box("Aspen: Hm. Whatever.", 50, 880, (255, 255, 255))
  text_a16=cl.Text_box("There is a loud banging coming from next door.", 50, 880, (255, 255, 255))
  text_a17=cl.Text_box("Aspen: ... and that would be Jan.", 50, 880, (255, 255, 255))
  text_a18=cl.Text_box("Aspen: You can go talk to him if you want.", 50, 880, (255, 255, 255))

  text_a19=cl.Text_box("Aspen is staring out the windows.", 50, 880, (255, 255, 255))
  text_a20=cl.Text_box("Her room has a few statues in it.", 50, 880, (255, 255, 255))
  text_a21=cl.Text_box("Aspen: Like the statues? Made them myself.", 50, 880, (255, 255, 255))
  text_a22=cl.Text_box("Aspen: Not much else to do in here...", 50, 880, (255, 255, 255))

  text_a23=cl.Text_box("Aspen: Wait... is that...?", 50, 880, (255, 255, 255))
  text_a24=cl.Text_box("Aspen: I can't believe it worked.", 50, 880, (255, 255, 255))
  text_a25=cl.Text_box("Aspen: Pretty sure there are 3 pieces in total.", 50, 880, (255, 255, 255))
  text_a26=cl.Text_box("Aspen: Player, you need to get all 3.", 50, 880, (255, 255, 255))
  text_a27=cl.Text_box("Aspen: This could be our ticket out of here!", 50, 880, (255, 255, 255))

  text_a28=cl.Text_box("Aspen: You got all three? Yes! Now I can finally make a key!", 50, 880, (255, 255, 255))
  text_a29=cl.Text_box("DEVon: 11111n00pe. n0 absolutely not.", 50, 880, (255, 255, 255))
  text_a30=cl.Text_box("Aspen: What are you going to do ab0ou! !t?*()", 50, 880, (255, 255, 255))
  text_a31=cl.Text_box("Aspen: I m3a3n, y090u c8n't!T1 c0898m3 h3r3r0329r", 50, 880, (255, 255, 255))
  text_a32=cl.Text_box("DEVon: i don't need to.", 50, 880, (255, 255, 255))         
  text_a33=cl.Text_box("87eiyrh8w47ithfusdrust6y4387uefgb834i7tguf", 50, 880, (255, 255, 255))
  text_a34=cl.Text_box("...", 50, 880, (255, 255, 255))
  text_a35=cl.Text_box("Everything is gone.", 50, 880, (255, 255, 255))
  text_a36=cl.Text_box("Everything except a disk on the ground.", 50, 880, (255, 255, 255))
  text_a37=cl.Text_box("You pick it up9986986", 50, 880, (255, 255, 255))
  
  text_a38=cl.Text_box("DEVon: ... i'm not convincing you am i.", 50, 880, (255, 255, 255))

  text_a39=cl.Text_box("DEVon: leave. leave please l3389147ave. j6786st l2893ve0.", 50, 880, (255, 255, 255))
  text_a40=cl.Text_box("DEVon: you'll get glitch3diuqewt r38roifeef", 50, 880, (255, 255, 255))
  text_a41=cl.Text_box("lifuhwyrbjtgvuyrtehfjuyv02974r68tuyngejc", 50, 880, (255, 255, 255))

  stay=True
  waiting=True

  while stay:

    #2 is Aspen's corrupt file. While she's not corrupted, things proceed as usual.
    if 2 not in corrupt_files:
      background=py.image.load("Room Art/aspenRoom.png")
      #Load the NPC image and position it over the background.
      aspen=py.image.load("NPC Sprites/Aspen.png")
      
      screen.blit(background, (0, 0))
      screen.blit(aspen, (200, 400))
      py.display.flip()
      
      rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
      py.display.update()

      #The first number in call_track tracks how many times Aspen's room has been visited. If it hasn't been visited at all, then there is exposition text.
      if call_track[0]==0:
        text_boxes=[text_a1, text_a2, text_a3, text_a4, text_a5, text_a6, text_a7, text_a8, text_a9, text_a10, text_a11, text_a12, text_a13, text_a14, text_a15, text_a16, text_a17, text_a18]
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        while text_box_idx!=17:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
      
      #The game is not linear, so this ensures that if there is any text remaining it gets removed no matter what.
      py.draw.rect(screen, (0, 0, 0), py.Rect(50, 880, 800, 60))

      #If you don't have the key mould and you have been in Aspen's room before, play this.
      if len(key_mould)==0 and call_track[0]!=0:
        text_boxes=[text_a19, text_a20, text_a21, text_a22]
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        while text_box_idx!=3:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
      
      else:
        #If the key mould is not complete, play this.
        if len(key_mould)>0 and len(key_mould)!=3:
          text_boxes=[text_a23, text_a24, text_a25, text_a26, text_a27]
          text_box_idx=0
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
          while text_box_idx!=4:
            event=py.event.wait()
            if event.type==KEYDOWN and event.key==K_RETURN:
              current_text.remove()
              text_box_idx+=1
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
        
        #If it is complete...
        elif len(key_mould)==3:
          text_boxes=[text_a28, text_a29, text_a30, text_a31, text_a32, text_a33, text_a34, text_a35, text_a36, text_a37]
          text_box_idx=0
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
          while text_box_idx!=9:
            event=py.event.wait()
            if event.type==KEYDOWN and event.key==K_RETURN:
              current_text.remove()
              text_box_idx+=1
              
              #Aspen corrupts partway through the text, so everything changes accordingly.
              if text_box_idx>=5:
                background=py.image.load("Room Art/aspenroom2.png")
                screen.blit(background, (0, 0))
                
                rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
                py.display.update()
                
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()

          #Once you've gotten all three pieces, you get the stone key and a corrupt file.
          stone_key=True
          corrupt_files.append(2)
    
    #When Aspen is corrupted, the background and text are different.
    else:
      background=py.image.load("Room Art/aspenroom2.png")
      screen.blit(background, (0, 0))
      py.display.flip()
      rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
      py.display.update()
      text_boxes=[text_a35, text_a33, text_a39, text_a40, text_a41]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      while text_box_idx!=4:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
          
    text_boxes=[text_leave, text_a38]
    text_box_idx=-1
    while text_box_idx!=1:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False
      else:
        current_text.draw()
        py.display.flip()
    stay=False    
  
  return stone_key, corrupt_files
  

def jan_room(butcher_knife, corrupt_files, call_track):
  """
  Jan's room. Plot relevant.

  Lets you get a corrupt file, which is necessary to beat the game.

  Parameters:
  butcher_knife (bool): A butcher knife. Can be obtained from the dining room. Needed to get Jan's corrupt file.

  corrupt_files (list): A list of integers, each representing a corrupt file. 

  call_track (list): A list of two integers, each keeping track of how many times either Aspen's room or Jan's room has been visited.

  Returns:
  corrupt_files, either with a number appended or no change at all.
  """
  text_j1=cl.Text_box("A boy is slamming his head on the window bars.", 50, 880, (255, 255, 255))
  text_j2=cl.Text_box("He turns when you enter.", 50, 880, (255, 255, 255))
  text_j3=cl.Text_box("The burst veins beneath his skin bruise it blue.", 50, 880, (255, 255, 255))
  text_j4=cl.Text_box("Blood trickles sluggishly over one eye.", 50, 880, (255, 255, 255))
  text_j5=cl.Text_box("Jan: New blood!", 50, 880, (255, 255, 255))
  text_j6=cl.Text_box("Jan: So, you trapped here too?", 50, 880, (255, 255, 255))
  text_j7=cl.Text_box("Jan: No... you smell like meat. A player!", 50, 880, (255, 255, 255))
  text_j8=cl.Text_box("Jan:... oh, Aspen sent you? Great!", 50, 880, (255, 255, 255))
  text_j9=cl.Text_box("Jan: I'm trying to break through the stupid bars.", 50, 880, (255, 255, 255))
  text_j10=cl.Text_box("Jan: If I had a knife or something...", 50, 880, (255, 255, 255))
  text_j11=cl.Text_box("Jan: Ahahahahahahahahahah210eu0dusij!!!!!!!", 50, 880, (255, 255, 255))

  text_j12=cl.Text_box("Jan is banging his head on the window.", 50, 880, (255, 255, 255))
  text_j13=cl.Text_box("Despite the bruising, he seems to feel no pain.", 50, 880, (255, 255, 255))

  text_j14=cl.Text_box("Jan: You... you brought a kn1fe!112!02981", 50, 880, (255, 255, 255))
  text_j15=cl.Text_box("Jan: Oh, this is s1mpl7767 m6rv3l0uss42s645s", 50, 880, (255, 255, 255))
  text_j16=cl.Text_box("Jan: D00nn'97t67 y0808u870 6gr33214, Dev30m2938ie1!!", 50, 880, (255, 255, 255))
  text_j17=cl.Text_box("DEVon: d3829718am9!t897 pl6698y333r!90821", 50, 880, (255, 255, 255))
  text_j18=cl.Text_box("DEVon: wh2379112y9 d!!1287d y0218031u d120930o0 t2981h6t", 50, 880, (255, 255, 255))
  text_j19=cl.Text_box("Jan: Aha847re6ufw8iergs7w98ert!!!*26112@!21", 50, 880, (255, 255, 255))
  text_j20=cl.Text_box("Jan: Y089U(7323'R2371917243E N312879xt68372 DE79318273", 50, 880, (255, 255, 255))
  text_j21=cl.Text_box("Jan saws at the bars wildly.", 50, 880, (255, 255, 255))
  text_j22=cl.Text_box("Blood stains his grinning teeth.", 50, 880, (255, 255, 255))
  text_j23=cl.Text_box("The bars start to crackkk213819847812913", 50, 880, (255, 255, 255))
  text_j24=cl.Text_box("hr6tr67dxghr35tr3f5", 50, 880, (255, 255, 255))
  text_j25=cl.Text_box("DEVon: y0989u89 ar982379r hdse2e287989321", 50, 880, (255, 255, 255))
  text_j26=cl.Text_box("... the room is gone. So is Jan.", 50, 880, (255, 255, 255))
  text_j27=cl.Text_box("Lying on the ground is a disc, which you pick up.", 50, 880, (255, 255, 255))
  text_j28=cl.Text_box("It seems... malevolent.", 50, 880, (255, 255, 255))

  text_j29=cl.Text_box("DEVon: you're judging me, aren't you.", 50, 880, (255, 255, 255))
  text_j30=cl.Text_box("DEVon: trust me.", 50, 880, (255, 255, 255))
  text_j31=cl.Text_box("DEVon: there's a reason i locked them up.", 50, 880, (255, 255, 255))

  text_j32=cl.Text_box("DEVon: leave. leave please l3389147ave. j6786st l2893ve0.", 50, 880, (255, 255, 255))
  text_j33=cl.Text_box("DEVon: you'll get glitch3diuqewt r38roifeef", 50, 880, (255, 255, 255))
  text_j34=cl.Text_box("lifuhwyrbjtgvuyrtehfjuyv02974r68tuyngejc", 50, 880, (255, 255, 255))

  stay=True
  waiting=True

  while stay:
    if 1 not in corrupt_files:
      background=py.image.load("Room Art/janRoom.png")
      npc=py.image.load("NPC Sprites/Jan.png")
      #Resize the image.
      npc=py.transform.scale(npc, (400, 400))
      
      screen.blit(background, (0, 0))
      screen.blit(npc, (200, 200))
      py.display.flip()
      
      rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
      py.display.update()
      
      if call_track[1]==0:
        text_boxes=[text_j1, text_j2, text_j3, text_j4, text_j5, text_j6, text_j7, text_j8, text_j9, text_j10, text_j11]
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        while text_box_idx!=10:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()

      if butcher_knife==False:
        #If you don't have the butcher knife but have visited Jan's room before, special text plays.
        if call_track[1]!=0:
          text_boxes=[text_j12, text_j13]
          text_box_idx=0
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
          while text_box_idx!=1:
            event=py.event.wait()
            if event.type==KEYDOWN and event.key==K_RETURN:
              current_text.remove()
              text_box_idx+=1
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
      #If you do have the knife, this plays.
      else:
        text_boxes=[text_j14, text_j15, text_j16, text_j17, text_j18, text_j19, text_j20, text_j21, text_j22, text_j23, text_j24, text_j25, text_j26, text_j27, text_j28]
        text_box_idx=0
        py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        
        while text_box_idx!=14:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            if text_box_idx>=10:
              background=py.image.load("Room Art/janroom2.png")
              screen.blit(background, (0, 0))
              py.display.flip()
              rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
              py.display.update()
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
        corrupt_files.append(1)
    
    else:
      background=py.image.load("Room Art/janroom2.png")
      screen.blit(background, (0, 0))
      py.display.flip()
      
      rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
      py.display.update()
      
      text_boxes=[text_j32, text_j33, text_j34]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      while text_box_idx!=2:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
    
    text_boxes=[text_leave, text_j29, text_j30, text_j31]
    text_box_idx=-1
    while text_box_idx!=3:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False
      else:
        current_text.draw()
        py.display.flip()
    
    stay=False
  
  return corrupt_files

def main_office(matchbook, wax_candle):
  """
  The main office. 
  
  Lets you get a matchbook and candle, both of which are needed to obtain other items.

  Parameters:
  matchbook (bool): A matchbook. Can be used with poppy tea to get a third of the key mould.

  wax_candle (bool): A wax candle. Can be used with the spoon to get the butcher knife.

  Returns:
  The value of matchbook.
  The value of wax_candle.
  """
  text_o1=cl.Text_box("The office is lit with wax candles.", 50, 880, (255, 255, 255))
  text_o2=cl.Text_box("The flames cast dramatic shadows over the walls.", 50, 880, (255, 255, 255))
  
  text_o3=cl.Text_box("No one is in there but a drawer rests just slightly ajar.", 50, 880, (255, 255, 255))
  text_o4=cl.Text_box("Search the drawer?", 50, 880, (255, 255, 255))

  text_o5=cl.Text_box("You rummage through the drawer.", 50, 880, (255, 255, 255))
  text_o6=cl.Text_box("In it is a matchbook and an unlit candle.", 50, 880, (255, 255, 255))
  text_o7=cl.Text_box("You decide to keep them with you.", 50, 880, (255, 255, 255))

  text_o8=cl.Text_box("It's hardly polite to look through someone else's things.", 50, 880, (255, 255, 255))
  text_o9=cl.Text_box("You left the drawer alone.", 50, 880, (255, 255, 255))

  text_o10=cl.Text_box("It smells of old parchment and smoke.", 50, 880, (255, 255, 255))
  text_o11=cl.Text_box("It's a virtual environment.", 50, 880, (255, 255, 255))

  text_o12=cl.Text_box("DEVon:... it has a smell.", 50, 880, (255, 255, 255))
  text_o13=cl.Text_box("DEVon: no i don't know why.", 50, 880, (255, 255, 255))
  text_o14=cl.Text_box("DEVon: i didn't put that in there.", 50, 880, (255, 255, 255))
  text_o15=cl.Text_box("DEVon: ...", 50, 880, (255, 255, 255))

  stay=True
  waiting=True

  while stay:
    background=py.image.load("Room Art/mainoffice.png")
    screen.blit(background, (0, 0))
    py.display.flip()
    
    rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
    py.display.update()
    
    text_boxes=[text_o1, text_o2]
    text_box_idx=0
    current_text=text_boxes[text_box_idx]
    current_text.draw()
    py.display.flip()
    while text_box_idx!=1:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()

    #While you don't have the matchbook or wax candle, you have the option to get them.
    if matchbook==False or wax_candle==False:
      text_boxes=[text_o3, text_o4, text_yes_no]
      current_text.remove()
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      while text_box_idx!=2:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()

      while waiting:
        event=py.event.wait()
        
        if event.type==KEYDOWN and event.key==121:
          current_text.remove()
          
          text_boxes=[text_o5, text_o6, text_o7]
          text_box_idx=0
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
          
          while text_box_idx!=2:
            event=py.event.wait()
            if event.type==KEYDOWN and event.key==K_RETURN:
              current_text.remove()
              text_box_idx+=1
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
          
          matchbook=True
          wax_candle=True
          waiting=False
        
        elif event.type==KEYDOWN and event.key==110:
          current_text.remove()
          
          text_boxes=[text_o8, text_o9]
          text_box_idx=0
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
          
          while text_box_idx!=1:
            event=py.event.wait()
            if event.type==KEYDOWN and event.key==K_RETURN:
              current_text.remove()
              text_box_idx+=1
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
          waiting=False
        
        else:
          current_text.draw()
          py.display.flip()
    
    else:
      current_text.remove()
      
      text_boxes=[text_o10, text_o11]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      
      while text_box_idx!=1:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
          
    text_boxes=[text_o12, text_o13, text_o14, text_o15]
    text_box_idx=-1
    waiting=True
    
    while text_box_idx!=3:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False   
      else:
        current_text.draw()
        py.display.flip()

    stay=False
        
  return matchbook, wax_candle 

def medical_wing(pill_bottle, key_mould):
  """
  The medical wing. You can exchange a bottle of pills to get a third of the key mould here.

  Parameters:
  pill_bottle (bool): A bottle of pills. Can be traded.

  key_mould (list): A list of integers, each representing a third of the key mould. All three allow you to get the stone key.

  Returns: 
  key_mould, either with a number appended or no change at all.

  """
  text_m1=cl.Text_box("The medical wing is airy and bright.", 50, 880, (255, 255, 255))
  text_m2=cl.Text_box("A nurse nearly runs you over.", 50, 880, (255, 255, 255))
  text_m3=cl.Text_box("Nurse: Where is it. Where is it.", 50, 880, (255, 255, 255))
  text_m4=cl.Text_box("Nurse: Where is it. The pills. Where is it.", 50, 880, (255, 255, 255))

  text_m5=cl.Text_box("You take a step inside.", 50, 880, (255, 255, 255))
  text_m6=cl.Text_box("The nurse hones in on you like a missile.", 50, 880, (255, 255, 255))
  text_m7=cl.Text_box("Nurse: You found them! The pills!", 50, 880, (255, 255, 255))
  text_m8=cl.Text_box("She grabs them out of your pocket.", 50, 880, (255, 255, 255))
  text_m9=cl.Text_box("Nurse: Here, take this.", 50, 880, (255, 255, 255))
  text_m10=cl.Text_box("Nurse: It seems pretty useless but whatever.", 50, 880, (255, 255, 255))

  text_m11=cl.Text_box("It seems pretty standard.", 50, 880, (255, 255, 255))
  text_m12=cl.Text_box("The beds look comfortable.", 50, 880, (255, 255, 255))
  text_m13=cl.Text_box("All of a sudden... you feel drowsy.", 50, 880, (255, 255, 255))

  text_m14=cl.Text_box("DEVon: not a good idea to lie down.", 50, 880, (255, 255, 255))
  text_m15=cl.Text_box("DEVon: i didn't make the beds.", 50, 880, (255, 255, 255))
  text_m16=cl.Text_box("DEVon: the last players who did...", 50, 880, (255, 255, 255))

  stay=True
  waiting=True

  while stay:
    background=py.image.load("Room Art/medicalwing.png")
    npc=py.image.load("NPC Sprites/Nurse.png")
    if 1 not in key_mould:
      npc=py.transform.scale(npc, (700, 700))
      screen.blit(background, (0, 0))
      screen.blit(npc, (100, 280))
      py.display.flip()
      rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
      py.display.update()

      if pill_bottle==False:
        text_boxes=[text_m1, text_m2, text_m3, text_m4]
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        
        while text_box_idx!=3:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
      
      else:
        text_boxes=[text_m5, text_m6, text_m7, text_m8, text_m9, text_m10, key_text1, key_text2]
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        
        while text_box_idx!=7:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
        key_mould.append(1)
        
    else:
      #Resize the NPC when the nurse isn't hunting for pills, to match with the text.
      npc=py.transform.scale(npc, (300, 300))
      
      screen.blit(background, (0, 0))
      screen.blit(npc, (200, 400))
      py.display.flip()
      
      rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
      py.display.update()
      
      text_boxes=[text_m11, text_m12, text_m13]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      
      while text_box_idx!=2:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()

    text_boxes=[text_m14, text_m15, text_m16, text_leave]
    text_box_idx=-1
    while text_box_idx!=3:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False   
      else:
        current_text.draw()
        py.display.flip()
    
    stay=False

  return key_mould

def kitchen(poppies, spoon, poppy_tea):
  """
  The kitchen. You can trade poppies for spoon and poppy tea, which are necessary to get other items.

  Parameters:
  poppies (bool): Poppies. Can be traded and are obtained from the greenhouse.

  spoon (bool): A spoon. Used with the wax candle to get the butcher knife from the dining room.

  poppy_tea (bool): Poppy tea. Can be used with the matchbook to get a third of the key mould.

  Returns:
  The value of spoon.
  The value of poppy_tea.
  """
  text_k1=cl.Text_box("Chef: nononononononono IT CAN'T BE!!!", 50, 880, (255, 255, 255))
  text_k2=cl.Text_box("Chef: They're gone. They're gone!", 50, 880, (255, 255, 255))
  text_k3=cl.Text_box("Chef: That useless gardener!!", 50, 880, (255, 255, 255))
  text_k4=cl.Text_box("Chef: You! Do you have poppies??...", 50, 880, (255, 255, 255))

  text_k5=cl.Text_box("Chef: No?", 50, 880, (255, 255, 255))
  text_k6=cl.Text_box("Chef: Then why are you here?? GET OUT!!!", 50, 880, (255, 255, 255))
  
  text_k7=cl.Text_box("Chef: Yes?", 50, 880, (255, 255, 255))
  text_k8=cl.Text_box("Chef: GIVE THEM OVER RIGHT THIS INSTANT!!!", 50, 880, (255, 255, 255))
  text_k9=cl.Text_box("...", 50, 880, (255, 255, 255))
  text_k10=cl.Text_box("He appears to be brewing something.", 50, 880, (255, 255, 255))
  text_k11=cl.Text_box("Chef: Ah, thank you. You may leave now.", 50, 880, (255, 255, 255))
  text_k12=cl.Text_box("Chef: What? You want something?", 50, 880, (255, 255, 255))
  text_k13=cl.Text_box("Chef: Goodness, youth these days are so petty.", 50, 880, (255, 255, 255))
  text_k14=cl.Text_box("Chef: Can your reward not be a deed well done?", 50, 880, (255, 255, 255))
  text_k15=cl.Text_box("Chef: Fine. Take these.", 50, 880, (255, 255, 255))
  text_k16=cl.Text_box("He gives you a spoon and some sort of tea.", 50, 880, (255, 255, 255))
  text_k17=cl.Text_box("Inhaling the steam makes you drowsy.", 50, 880, (255, 255, 255))
  text_k18=cl.Text_box("Chef: Now leave!!", 50, 880, (255, 255, 255))

  text_k19=cl.Text_box("The chef is bustling about, humming.", 50, 880, (255, 255, 255))
  text_k20=cl.Text_box("You reach for a kitchen knife close by.", 50, 880, (255, 255, 255))
  text_k21=cl.Text_box("Chef: HOLD IT!!", 50, 880, (255, 255, 255))
  text_k22=cl.Text_box("Chef: Don't youth know knife safety?", 50, 880, (255, 255, 255))
  text_k23=cl.Text_box("Chef: Lord Jesus Christ and his dog!", 50, 880, (255, 255, 255))
  text_k24=cl.Text_box("Chef: What are youth learning nowadays?", 50, 880, (255, 255, 255))
  text_k25=cl.Text_box("Chef: No knives! Out, I say! Out!", 50, 880, (255, 255, 255))

  text_k26=cl.Text_box("You decide to take his advice.", 50, 880, (255, 255, 255))
  text_k27=cl.Text_box("DEVon: can't you see this is dangerous?", 50, 880, (255, 255, 255))
  text_k28=cl.Text_box("DEVon: the map will let you leave. backspace to leave.", 50, 880, (255, 255, 255))

  stay=True
  waiting=True

  while stay:
    background=py.image.load("Room Art/kitchen.png")
    npc=py.image.load("NPC Sprites/Chef.png")
    
    screen.blit(background, (0, 0))
    screen.blit(npc, (400, 480))
    py.display.flip()
    
    rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
    py.display.update()
    
    if spoon==False and poppy_tea==False:
      text_boxes=[text_k1, text_k2, text_k3, text_k4]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      while text_box_idx!=3:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()

      while waiting:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          waiting=False
        else:
          current_text.draw()
          py.display.flip()

      #reset waiting for later use.
      waiting=True
      
      if poppies==False:
        current_text.remove()
        text_boxes=[text_k5, text_k6]
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        
        while text_box_idx!=1:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
      else:
        current_text.remove()
        text_boxes=[text_k7, text_k8, text_k9, text_k10, text_k11, text_k12, text_k13, text_k14, text_k15, text_k16, text_k17, text_k18]
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        
        while text_box_idx!=11:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
        spoon=True
        poppy_tea=True
    
    else:
      text_box_idx=0
      text_boxes=[text_k19, text_k20, text_k21, text_k22, text_k23, text_k24, text_k25]
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      
      while text_box_idx!=6:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
    
    text_boxes=[text_k26, text_k27, text_k28]
    text_box_idx=-1
    while text_box_idx!=2:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False
      else:
        current_text.draw()
        py.display.flip()
    
    stay=False
    
  return spoon, poppy_tea

def dining_room(spoon, wax_candle, butcher_knife):
  """
  The dining room. Allows you to get a butcher knife.

  Parameters:
  spoon (bool): A spoon. Used with the wax candle to get the butcher knife from the dining room.

  wax_candle (bool): A wax candle. Can be used with the spoon to get the butcher knife.

  butcher_knife (bool): A butcher knife. Can be obtained after getting the spoon and candle. Needed to get Jan's corrupt file.

  Returns:
  The value of butcher_knife.
  """
  text_d1=cl.Text_box("The dining room is dark.", 50, 880, (255, 255, 255))
  text_d2=cl.Text_box("Wisps of light come through a crack in a wall.", 50, 880, (255, 255, 255))
  text_d3=cl.Text_box("The person there appears... malnourished.",50, 880, (255, 255, 255))
  text_d4=cl.Text_box("???: I'm hungry. I'm so hungry.", 50, 880, (255, 255, 255))
  text_d5=cl.Text_box("Hungry NPC: I have no spoon and no light.", 50, 880, (255, 255, 255))
  text_d6=cl.Text_box("Hungry NPC: I need light. I need a spoon. I need light.", 50, 880, (255, 255, 255))
  text_d7=cl.Text_box("...", 50, 880, (255, 255, 255))

  text_d9=cl.Text_box("Hungry NPC: Is that... ??", 50, 880, (255, 255, 255))
  text_d10=cl.Text_box("Hungry NPC: !! My spoon! My light!", 50, 880, (255, 255, 255))
  text_d11=cl.Text_box("Hungry NPC: Oh, delightful day!", 50, 880, (255, 255, 255))
  text_d12=cl.Text_box("Hungry NPC: Finally, I shall rise once more!", 50, 880, (255, 255, 255))
  text_d13=cl.Text_box("The room is lit up.", 50, 880, (255, 255, 255))
  text_d14=cl.Text_box("The hungry NPC peers at you with too-bright eyes.", 50, 880, (255, 255, 255))
  text_d15=cl.Text_box("He looks at you and his stomach growls.", 50, 880, (255, 255, 255))
  text_d16=cl.Text_box("Quickly you grab the butcher knife.", 50, 880, (255, 255, 255))

  text_d17=cl.Text_box("The dining room is a tiny, claustrophobic space.", 50, 880, (255, 255, 255))
  text_d18=cl.Text_box("There are scratch marks on the floor and walls.", 50, 880, (255, 255, 255))
  text_d19=cl.Text_box("The lit candle is burning away.", 50, 880, (255, 255, 255))
  text_d20=cl.Text_box("What will happen when it burns out?", 50, 880, (255, 255, 255))

  text_d8=cl.Text_box("Perhaps it's best to leave.", 50, 880, (255, 255, 255))
  text_d21=cl.Text_box("DEVon: he can't hurt you in a game.", 50, 880, (255, 255, 255))
  text_d22=cl.Text_box("DEVon: ... i hope.", 50, 880, (255, 255, 255))
  
  stay=True
  waiting=True

  while stay:
    #The butcher knife is obtained the first time you bring the hungry NPC what he wants. This guarantees that.
    if butcher_knife==False:
      background=py.image.load("Room Art/diningroom1.png")
      screen.blit(background, (0, 0))
      py.display.flip()
      
      rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
      py.display.update()

      #You need both items to proceed properly.
      if spoon==False or wax_candle==False:
        text_boxes=[text_d1, text_d2, text_d3, text_d4, text_d5, text_d6, text_d7]
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        
        while text_box_idx!=6:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
      
      else:
        text_boxes=[text_d1, text_d2, text_d3, text_d4, text_d5, text_d9, text_d10, text_d11, text_d12, text_d13, text_d14, text_d15, text_d16]
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        
        while text_box_idx!=12:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            
            if text_box_idx>=8:
              background=py.image.load("Room Art/diningroom.png")
              npc=py.image.load("NPC Sprites/hungryNPC.png")
              
              npc=py.transform.scale(npc, (600, 600))
              screen.blit(background, (0, 0))
              screen.blit(npc, (100, 200))
              py.display.flip()
              
              rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
              py.display.update()
            
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
        
        butcher_knife=True
    
    else:
      background=py.image.load("Room Art/diningroom.png")
      npc=py.image.load("NPC Sprites/hungryNPC.png")
      npc=py.transform.scale(npc, (600, 600))
      
      screen.blit(background, (0, 0))
      screen.blit(npc, (100, 200))
      py.display.flip()
      
      rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
      py.display.update()
      
      text_boxes=[text_d17, text_d18, text_d19, text_d20]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      
      while text_box_idx!=3:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()

    text_boxes=[text_d8, text_d21, text_d22]
    text_box_idx=-1
    
    while text_box_idx!=2:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False
      else:
        current_text.draw()
        py.display.flip()

    stay=False
      
  return butcher_knife

def rec_room(key_mould):
  """
  The recreation room. Allows you to get another third of the key mould after winning three rounds of rock paper scissors against an NPC.

  Parameters:
  key_mould (list): A list of integers, each representing a third of the key mould. All three allow you to get the stone key.

  Returns:
  key_mould, either with a number appended or no change at all.
  
  """
  text_r1=cl.Text_box("Random NPC: Bahahaha! I am the RPS Champion!!!", 50, 880, (255, 255, 255))
  text_r2=cl.Text_box("Random NPC: What's that? You don't know what RPS is?", 50, 880, (255, 255, 255))
  text_r3=cl.Text_box("Random NPC: It's only the hottest game in town!", 50, 880, (255, 255, 255))
  text_r4=cl.Text_box("Random NPC: ROCK PAPER SCISSORS!", 50, 880, (255, 255, 255))
  text_r5=cl.Text_box("Random NPC: Tell you what.", 50, 880, (255, 255, 255))
  text_r6=cl.Text_box("Random NPC: Win three rounds and I'll give you something nice!", 50, 880, (255, 255, 255))

  text_r7=cl.Text_box("Pick r for rock, p for paper, or s for scissors!", 50, 880, (255, 255, 255))

  text_r8=cl.Text_box("Random NPC: Bahahaha! I win AGAIN!!", 50, 880, (255, 255, 255))
  text_r9=cl.Text_box("Random NPC: What's that? You want to try again?", 50, 880, (255, 255, 255))
  text_r10=cl.Text_box("Random NPC: Alright...", 50, 880, (255, 255, 255))
  text_r11=cl.Text_box("Random NPC: I WILL DESTROY YOU!!!", 50, 880, (255, 255, 255))

  text_r12=cl.Text_box("Random NPC: Impossible!! I lost??", 50, 880, (255, 255, 255))
  text_r13=cl.Text_box("Random NPC: I demand a rematch!", 50, 880, (255, 255, 255))
  text_r33=cl.Text_box("Random NPC: ... I have lost 3 rounds?", 50, 880, (255, 255, 255))

  text_r14=cl.Text_box("Random NPC: A tie!", 50, 880, (255, 255, 255))
  text_r15=cl.Text_box("Random NPC: I came so close to losing...", 50, 880, (255, 255, 255))
  text_r16=cl.Text_box("Random NPC: Again!!!", 50, 880, (255, 255, 255))

  text_r17=cl.Text_box("Random NPC: WHAT?!?!", 50, 880, (255, 255, 255))
  text_r18=cl.Text_box("Random NPC: I, the great RANDOM NPC, was defeated??", 50, 880, (255, 255, 255))
  text_r19=cl.Text_box("Random NPC: IMPOSSIBLE!!", 50, 880, (255, 255, 255))
  text_r20=cl.Text_box("Random NPC:...", 50, 880, (255, 255, 255))
  text_r21=cl.Text_box("Random NPC:... fine, a promise is a promise.", 50, 880, (255, 255, 255))
  text_r22=cl.Text_box("Random NPC: Here. Take this.", 50, 880, (255, 255, 255))

  text_r23=cl.Text_box("Random NPC: I knew it!! I remain undefeated!!", 50, 880, (255, 255, 255))
  text_r24=cl.Text_box("Random NPC: Why don't you go to the hospital, player?", 50, 880, (255, 255, 255))
  text_r25=cl.Text_box("Random NPC: You seem to have lost your spine!", 50, 880, (255, 255, 255))
  text_r26=cl.Text_box("Random NPC: Come back when you're ready to face me!", 50, 880, (255, 255, 255))

  text_r27=cl.Text_box("Random NPC: What am I, now that I am not the RPS champion??", 50, 880, (255, 255, 255))
  text_r28=cl.Text_box("Random NPC: I have no purpose!", 50, 880, (255, 255, 255))
  text_r29=cl.Text_box("Random NPC: I cannot aid the main questline anymore!", 50, 880, (255, 255, 255))
  text_r30=cl.Text_box("Random NPC: Go on, player. Go on without me.", 50, 880, (255, 255, 255))

  text_r31=cl.Text_box("DEVon: no i do not know where random npc came from.", 50, 880, (255, 255, 255))
  text_r32=cl.Text_box("DEVon: my control here is... slipping.", 50, 880, (255, 255, 255))

  stay=True
  win_count=0
  waiting=True

  while stay:
    background=py.image.load("Room Art/recroom.png")
    npc=py.image.load("NPC Sprites/randomNPC.png")
    npc=py.transform.scale(npc, (500, 500))
    
    screen.blit(background, (0, 0))
    screen.blit(npc, (200, 300))
    py.display.flip()
    
    rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
    py.display.update()

    #2 is obtained only once you've beaten the random NPC, so before that you get to play a game.
    if 2 not in key_mould:
      text_boxes=[text_r1, text_r2, text_r3, text_r4, text_r5, text_r6, text_yes_no]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      
      while text_box_idx!=6:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()

      while waiting:
        event=py.event.wait()
        
        if event.type==KEYDOWN and event.key==121:
          while win_count!=3:
            current_text.remove()
            current_text=text_r7
            current_text.draw()
            py.display.flip()
            
            event=py.event.wait()
            event=py.event.wait()
            event=py.event.wait()

            #r stands for rock, p for paper, and s for scissors.
            if event.type==KEYDOWN and event.key==114:
              player_choice='r'
            elif event.type==KEYDOWN and event.key==112:
              player_choice='p'
            elif event.type==KEYDOWN and event.key==115:
              player_choice='s'
            #If you do anything that isn't pressing the keys r, p, or s, your choice is automatically selected as r.
            else:
              player_choice='r'

            #the NPC's choice is of course random.
            npc_choice=rand.choice(['r', 'p', 's'])
  
            if npc_choice==player_choice:
              text_r7.remove()
              #text_leave is in there as a bandage fix to the fact that it wasn't displaying all my text. This occurs when the player and NPC tie.
              text_boxes=[text_r14, text_r15, text_r16, text_leave]
              text_box_idx=0
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
              
              while text_box_idx!=3:
                event=py.event.wait()
                if event.type==KEYDOWN and event.key==K_RETURN:
                  current_text.remove()
                  text_box_idx+=1
                  current_text=text_boxes[text_box_idx]
                  current_text.draw()
                  py.display.flip()
            
            #These are all the player's winning conditions.
            elif npc_choice=='s' and player_choice=='r' or npc_choice=='p' and player_choice=='s' or npc_choice=='r' and player_choice=='p':
              text_r7.remove()
              text_boxes=[text_r12, text_r13, text_r33]
              text_box_idx=0
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
              while text_box_idx!=2:
                event=py.event.wait()
                if event.type==KEYDOWN and event.key==K_RETURN:
                  current_text.remove()
                  text_box_idx+=1
                  current_text=text_boxes[text_box_idx]
                  current_text.draw()
                  py.display.flip()
              win_count+=1
            #Anything else is a player loss.
            else:
              text_r7.remove()
              text_boxes=[text_r8, text_r9, text_r10, text_r11, text_leave]
              text_box_idx=0
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
              
              while text_box_idx!=4:
                event=py.event.wait()
                if event.type==KEYDOWN and event.key==K_RETURN:
                  current_text.remove()
                  text_box_idx+=1
                  current_text=text_boxes[text_box_idx]
                  current_text.draw()
                  py.display.flip()
          
          #Occurs only once you've won the game.
          current_text.remove()
          text_boxes=[text_r17, text_r18, text_r19, text_r20, text_r21, text_r22]
          text_box_idx=0
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          while text_box_idx!=5:
            event=py.event.wait()
            if event.type==KEYDOWN and event.key==K_RETURN:
              current_text.remove()
              text_box_idx+=1
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
          key_mould.append(2)
          
          waiting=False
          
        elif event.type==KEYDOWN and event.key==110:
          current_text.remove()
          text_boxes=[text_r23, text_r24, text_r25, text_r26]
          text_box_idx=0
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
          
          while text_box_idx!=3:
            event=py.event.wait()
            if event.type==KEYDOWN and event.key==K_RETURN:
              current_text.remove()
              text_box_idx+=1
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
          waiting=False
        else:
          current_text.draw()
          py.display.flip()

      waiting=True
      
    else:
      text_boxes=[text_r27, text_r28, text_r29, text_r30]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      
      while text_box_idx!=3:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
    
    text_boxes=[text_r31, text_r32, text_leave]
    text_box_idx=-1
    while text_box_idx!=2:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False
      else:
        current_text.draw()
        py.display.flip()

    stay=False 
      
  return key_mould
  
def greenhouse(matchbook, poppy_tea, key_mould, poppies):
  """
  A greenhouse. It lets you get poppies and, if you have the matchbook and poppy tea, one third of the key mould.

  Parameters:
  matchbook (bool): A matchbook. Can be used with poppy tea to get a third of the key mould.

  poppy_tea (bool): Poppy tea. Can be used with the matchbook to get a third of the key mould.

  key_mould (list): A list of integers, each representing a third of the key mould. All three allow you to get the stone key.

  poppies (bool): Poppies. Can be traded to get poppy tea and the spoon.

  Returns:
  key_mould, either with a number appended or no change at all.
  """
  text_g1=cl.Text_box("The greenhouse is a breath of fresh air.", 50, 880, (255, 255, 255))
  text_g2=cl.Text_box("Vines cover the ceiling and walls.", 50, 880, (255, 255, 255))
  text_g3=cl.Text_box("The blooming wisteria tint the air with a sweet smell.", 50, 880, (255, 255, 255))
  
  text_g4=cl.Text_box("A patch of red draws your eye.", 50, 880, (255, 255, 255))
  text_g5=cl.Text_box("Gardener: Oh, hey! Been a while since we've had newcomers!", 50, 880, (255, 255, 255))
  text_g6=cl.Text_box("Gardener: I see you eyeing the poppies. Want some?", 50, 880, (255, 255, 255))
  
  text_g8=cl.Text_box("DEVon: the gardener looks like...", 50, 880, (255, 255, 255))
  text_g9=cl.Text_box("DEVon: how cruel of them", 50, 880, (255, 255, 255))

  text_g10=cl.Text_box("Gardener: Great! Here you go!", 50, 880, (255, 255, 255))
  text_g11=cl.Text_box("Gardener: Feel free to look around!", 50, 880, (255, 255, 255))

  text_g12=cl.Text_box("Gardener: Alright! Feel free to look around!", 50, 880, (255, 255, 255))


  text_g14=cl.Text_box("You notice a patch of vines covering a hole.", 50, 880, (255, 255, 255))
  text_g15=cl.Text_box("They're too dense for you to reach past and too strong to pull away.", 50, 880, (255, 255, 255))
  text_g16=cl.Text_box("You left it alone.", 50, 880, (255, 255, 255))

  text_g17=cl.Text_box("Using a match from your matchbook, you try to burn it away.", 50, 880, (255, 255, 255))
  text_g18=cl.Text_box("Gardener: Stop! What are you doing?", 50, 880, (255, 255, 255))
  text_g19=cl.Text_box("Gardener: Be more careful with fire!", 50, 880, (255, 255, 255))
  text_g20=cl.Text_box("Gardener: You're in a greenhouse!", 50, 880, (255, 255, 255))
  text_g21=cl.Text_box("You apologize and leave it alone.", 50, 880, (255, 255, 255))
  text_g22=cl.Text_box("Perhaps there's some way to... get rid of him?", 50, 880, (255, 255, 255))

  text_g23=cl.Text_box("You could burn it away, but the gardener would notice.", 50, 880, (255, 255, 255))
  text_g24=cl.Text_box("Give the gardener poppy tea to make him fall asleep?", 50, 880, (255, 255, 255))

  text_g25=cl.Text_box("Gardener: Oh, tea? Thank you!", 50, 880, (255, 255, 255))
  text_g26=cl.Text_box("Gardener: Hm... it's not quite to my taste.", 50, 880, (255, 255, 255))
  text_g27=cl.Text_box("Gardener: Maybe I should.. get... some....", 50, 880, (255, 255, 255))
  text_g28=cl.Text_box("Gardener:.......", 50, 880, (255, 255, 255))
  text_g29=cl.Text_box("He's asleep.", 50, 880, (255, 255, 255))
  text_g30=cl.Text_box("You burn away the vines, revealing an object sitting inside.", 50, 880, (255, 255, 255))

  text_g31=cl.Text_box("You decide to not drug the gardener and left the hole alone.", 50, 880, (255, 255, 255))
  
  stay=True
  text=True
  waiting=True
  
  while stay:
    background=py.image.load("Room Art/greenhouse.png")
    gardener=py.image.load("NPC Sprites/gardener.png")
    
    screen.blit(background, (0, 0))
    screen.blit(gardener, (300, 400))
    py.display.flip()
    
    rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
    py.display.update()

    text_boxes = [text_g1, text_g2, text_g3]
    text_box_idx = 0
    current_text=text_boxes[text_box_idx]
    current_text.draw()
    py.display.flip()
    
    while text:
      event = py.event.wait()
      if event.type == KEYDOWN and event.key == K_RETURN:
        current_text.remove()
        text_box_idx+=1
        
        if text_box_idx==3:
          if poppies==False:
            text_boxes=[text_g4, text_g5, text_g6, text_yes_no]
            text_box_idx=0
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
            
            while text_box_idx!=3:
              event=py.event.wait()
              if event.type==KEYDOWN and event.key==K_RETURN:
                current_text.remove()
                text_box_idx+=1
                current_text=text_boxes[text_box_idx]
                current_text.draw()
                py.display.flip()

            while waiting:
              event=py.event.wait()
              if event.type==KEYDOWN and event.key==121:
                current_text.remove()
                text_boxes=[text_g10, text_g11]
                text_box_idx=0
                current_text=text_boxes[text_box_idx]
                current_text.draw()
                py.display.flip()
                while text_box_idx!=1:
                  event=py.event.wait()
                  if event.type==KEYDOWN and event.key==K_RETURN:
                    current_text.remove()
                    text_box_idx+=1
                    current_text=text_boxes[text_box_idx]
                    current_text.draw()
                    py.display.flip()
                
                poppies=True
                waiting=False
              
              elif event.type==KEYDOWN and event.key==110:
                current_text.remove()
                current_text=text_g12
                event=py.event.wait()
                event=py.event.wait()

                #While you aren't pressing enter, keep drawing the current text. It would be fairly pointless to only have one text box in the text box list.
                while event.type!=KEYDOWN or event.key!=K_RETURN:
                  current_text.draw()
                  py.display.flip()
                  event=py.event.wait()
                waiting=False
             
              else:
                current_text.draw()
                py.display.flip()
            
          while 3 not in key_mould:

            #Not lumping matchbook and poppy tea together because there is different flavour text for each.
            if matchbook==False:
              current_text.remove()
              text_boxes=[text_g14, text_g15, text_g16]
              text_box_idx=0
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
              
              while text_box_idx<2:
                event=py.event.wait()
                if event.type==KEYDOWN and event.key==K_RETURN:
                  current_text.remove()
                  text_box_idx+=1
                  current_text=text_boxes[text_box_idx]
                  current_text.draw()
                  py.display.flip()
            
            elif poppy_tea==False:
              current_text.remove()
              text_boxes=[text_g14, text_g17, text_g18, text_g19, text_g20, text_g21, text_g22]
              text_box_idx=0
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
              
              while text_box_idx!=6:
                event=py.event.wait()
                if event.type==KEYDOWN and event.key==K_RETURN:
                  current_text.remove()
                  text_box_idx+=1
                  current_text=text_boxes[text_box_idx]
                  current_text.draw()
                  py.display.flip()
            
            else:
              current_text.remove()
              text_boxes=[text_g14, text_g23, text_g24, text_yes_no]
              waiting=True
              text_box_idx=0
              current_text=text_boxes[text_box_idx]
              current_text.draw()
              py.display.flip()
              
              while text_box_idx!=3:
                event=py.event.wait()
                if event.type==KEYDOWN and event.key==K_RETURN:
                  current_text.remove()
                  text_box_idx+=1
                  current_text=text_boxes[text_box_idx]
                  current_text.draw()
                  py.display.flip()
  
              while waiting:
                event=py.event.wait()
                if event.type==KEYDOWN and event.key==121:
                  current_text.remove()
                  text_boxes=[text_g25, text_g26, text_g27, text_g28, text_g29, text_g30, key_text1, key_text2]
                  text_box_idx=0
                  current_text=text_boxes[text_box_idx]
                  current_text.draw()
                  py.display.flip()
                  
                  while text_box_idx!=7:
                    event=py.event.wait()
                    if event.type==KEYDOWN and event.key==K_RETURN:
                      current_text.remove()
                      text_box_idx+=1
                      current_text=text_boxes[text_box_idx]
                      current_text.draw()
                      py.display.flip()
                  key_mould.append(3)
                  waiting=False
                
                elif event.type==KEYDOWN and event.key==110:
                  current_text.remove()
                  current_text=text_g31
                  event=py.event.wait()
                  event=py.event.wait()
                  
                  while event.type!=KEYDOWN or event.key!=K_RETURN:
                    current_text.draw()
                    py.display.flip()
                    event=py.event.wait()
                  waiting=False
                
                else:
                  current_text.draw()
                  py.display.flip()
            text=False
            break
            
          else:
            text=False
        
        else:
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
    
    waiting=True
    text_boxes=[text_leave, text_g8, text_g9]
    text_box_idx=0
    current_text=text_boxes[text_box_idx]
    
    while text_box_idx!=2:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False
      else:
        current_text.draw()
        py.display.flip()

    stay=False
  
  return poppies, key_mould

def REDACTED(stone_key, corrupt_files, end):
  """
  The endpoint of the game. Allows you to 'beat' the game if you have the stone key and both corrupt files, does nothing if you don't.

  Parameters:
  stone_key (bool): A stone key. Can be obtained once all three pieces of the key mould are found.

  corrupt_files (list): A list of integers, each representing a corrupt file. 

  end (bool): Starts out False. Becomes True once the game has reached all its ending conditions.

  Returns:
  The value of end.
  
  """
  text_l1=cl.Text_box("u7erik8t57u438wierufw4se8tiyuw49e8iufw8o3iyutr", 50, 880, (255, 255, 255))
  text_l2=cl.Text_box("???????????????????';'.[p[p/o9823912?:P912l3.e22\]1-4`", 50, 880, (255, 255, 255))
  text_l3=cl.Text_box("DEVon: y09382u're3928743 gl!t27f98c931y2h321231", 50, 880, (255, 255, 255))
  text_l4=cl.Text_box("D333V0n: le3216ave12337981298431`;.[2;1", 50, 880, (255, 255, 255))
  text_l5=cl.Text_box("............................................", 50, 880, (255, 255, 255))
  text_l6=cl.Text_box("You feel... cold.", 50, 880, (255, 255, 255))

  text_l7=cl.Text_box("The stone key seems to respond to your surroundings.", 50, 880, (255, 255, 255))
  text_l8=cl.Text_box("It shudders and vibrates the keyboard.", 50, 880, (255, 255, 255))
  text_l9=cl.Text_box("The screen shakes and glitches.", 50, 880, (255, 255, 255))
  text_l10=cl.Text_box("Floating in the middle of the mess is a door.", 50, 880, (255, 255, 255))
  text_l11=cl.Text_box("The discs are vibratingggggggggggggggggg12809", 50, 880, (255, 255, 255))
  text_l12=cl.Text_box("DEVon: stop. stop stop st008u02918", 50, 880, (255, 0, 0))
  text_l13=cl.Text_box("DEVon: tehhye892 2riefurgvu32989e3", 50, 880, (255, 0, 0))
  text_l14=cl.Text_box("DEV???][/;.[le128374hdhrpr323cry29p]14[c1kox[o", 50, 880, (255, 0, 0))
  text_l15=cl.Text_box("Jan: AHAHAHAHAHAHAHA!", 50, 880, (255, 0, 0))
  text_l16=cl.Text_box("Aspen: Thank you so much, player!", 50, 880, (255, 0, 0))
  text_l17=cl.Text_box("Aspen: Oh, you were delightful.", 50, 880, (255, 0, 0))
  text_l18=cl.Text_box("Jan: Oh DEVVIE!! Are you excited?", 50, 880, (255, 0, 0))
  text_l19=cl.Text_box("Aspen: Looks like you'll see your brother again!", 50, 880, (255, 0, 0))
  text_l20=cl.Text_box("Aspen: You won't be pulling off this trick again, DEVon.", 50, 880, (255, 0, 0))
  text_l21=cl.Text_box("Jan: Oh, the player! They're still here! How cute!!", 50, 880, (255, 0, 0))
  text_l22=cl.Text_box("Jan: Don't worry! It won't hurt!", 50, 880, (255, 0, 0))
  text_l23=cl.Text_box("You reach for the p00w33r but!00n0nn?};.]:>0921", 50, 880, (255, 0, 0))
  text_l24=cl.Text_box(";[/.;/213[21.49,2013ip1.31[2p312", 50, 880, (255, 0, 0))
  text_l25=cl.Text_box(";[/;[;/}:>L<{.12.][3(*&1231.{L21983", 50, 880, (255, 0, 0))

  stay=True
  waiting=True
  
  while stay:
    background=py.image.load("Room Art/redacted_1.png")
    screen.blit(background, (0, 0))
    py.display.flip()
    
    rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
    py.display.update()
    
    if stone_key==False or len(corrupt_files)!=2:
      text_boxes=[text_l1, text_l2, text_l3, text_l4, text_l5, text_l6]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      
      while text_box_idx!=5:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
    
    else:
      text_boxes=[text_l7, text_l8, text_l9, text_l10, text_l11, text_l12, text_l13, text_l4, text_l15, text_l16, text_l17, text_l18, text_l19, text_l20, text_l21, text_l22, text_l23]
      text_box_idx=0
      current_text=text_boxes[text_box_idx]
      current_text.draw()
      py.display.flip()
      
      while text_box_idx!=16:
        event=py.event.wait()
        if event.type==KEYDOWN and event.key==K_RETURN:
          current_text.remove()
          text_box_idx+=1
          
          if text_box_idx>=3:
            background=py.image.load("Room Art/redacted_2.png")
            screen.blit(background, (0, 0))
            py.display.flip()
            
            rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
            py.display.update()
          
          current_text=text_boxes[text_box_idx]
          current_text.draw()
          py.display.flip()
          #end exists so we know when to end the game.
          end=True
    
    text_boxes=[text_l24, text_l25]
    text_box_idx=-1
    
    while text_box_idx!=1:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        current_text.remove()
        text_box_idx+=1
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
    
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False
      else:
        current_text.draw()
        py.display.flip()

    stay=False 

  return end

def start():
  """
  The function at the start of the game. Gives instructions and exposition.

  Parameters:
  None

  Returns:
  None
  """
  text_c1=cl.Text_box("Use the arrow keys to move.", 50, 250, (255, 255, 255))
  text_c2=cl.Text_box("Use the enter key to go through text.", 50, 500, (255, 255, 255))

  text_c3=cl.Text_box("The program finishes loading.", 50, 880, (255, 255, 255))
  text_c4=cl.Text_box("It really doesn't seem like much.", 50, 880, (255, 255, 255))
  text_c5=cl.Text_box("...", 50, 880, (255, 255, 255))
  text_c6=cl.Text_box("DEVon: another one?", 50, 880, (255, 255, 255))
  text_c7=cl.Text_box("DEVon: you shouldn't be playing this.", 50, 880, (255, 255, 255))
  text_c8=cl.Text_box("DEVon: really. if you want to exit, just go to the map and press backspace.", 50, 880, (255, 255, 255))
  text_c9=cl.Text_box("DEVon: fine. whatever. the choice is yours.", 50, 880, (255, 255, 255))

  stay=True
  waiting=True

  while stay:
    screen.fill((0, 0, 0))
    text_c1.draw()
    text_c2.draw()
    py.display.flip()

    while waiting:

      event=py.event.wait()
      
      if event.type==KEYDOWN and event.key==K_RETURN:
        text_boxes=[text_c3, text_c4, text_c5, text_c6, text_c7, text_c8, text_c9]
        screen.fill((0, 0, 0))
        text_box_idx=0
        current_text=text_boxes[text_box_idx]
        current_text.draw()
        py.display.flip()
        
        while text_box_idx!=6:
          event=py.event.wait()
          if event.type==KEYDOWN and event.key==K_RETURN:
            current_text.remove()
            text_box_idx+=1
            current_text=text_boxes[text_box_idx]
            current_text.draw()
            py.display.flip()
        waiting=False
    
    waiting=True
    while waiting:
      event=py.event.wait()
      if event.type==KEYDOWN and event.key==K_RETURN:
        waiting=False
      else:
        text_c9.draw()
        py.display.flip()

    stay=False
  
  return

def game_over():
  """
  The function called at the end of the game. Simply concludes the game itself with some appropriate artwork.

  Parameters:
  None

  Returns:
  None
  """
  stay=True
  done=True
  
  while stay:
    
    #The background of the background image is transparent, so we change the screen colour so it looks decent.
    screen.fill((255, 255, 255))
    background=py.image.load("Game Screens/jan+aspen_end.png")
    screen.blit(background, (0, 0))
    py.display.flip()
    
    rectangle=py.draw.rect(screen, (0, 0, 0), py.Rect(0, 850, 800, 100))
    py.display.update()

    #Wait for the user to press enter before taking away the image and moving to the next loop.
    event=py.event.wait()
    if event.type==KEYDOWN and event.key==K_RETURN:
      stay=False
  
  while done:
    background=py.image.load("Game Screens/game_over.png")
    screen.blit(background, (0, 0))
    py.display.flip()
    event=py.event.wait()
    if event.type==KEYDOWN and event.key==K_RETURN:
      done=False
  
  return

screen=py.display.set_mode([SCREEN_WIDTH, SCREEN_HEIGHT])
                                                                                    